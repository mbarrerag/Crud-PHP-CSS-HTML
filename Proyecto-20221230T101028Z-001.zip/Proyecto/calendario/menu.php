<nav class="navbar navbar-expand navbar-dark bg-dark mb-5"> <!-- Clases bootstrap -->
    <ul class='navbar-nav'>
      
        <li class= "nav-item">
            <a class="nav-link" href="<?=ROOT?>/Patients/index.php">Citas</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?=ROOT?>/admin.html">Cerrar sesion </a>
        </li>
    <ul>
</nav>