<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vinculos afectivos en la familia</title>
  <!-- Conexiones -->
  <link rel="stylesheet" href="Estilos/styles.css">
  <link rel="stylesheet" href="Estilos/mq.css">
  <script src="https://kit.fontawesome.com/eb496ab1a0.js" crossorigin="anonymous"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

</head>

<body>

  <div class="linea0"></div>
  <!-- Header -->
  <header>
    <nav class="navbar navbar-expand-lg bg-light">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php"> <img src="Imagenes/Juego.png" alt="JuegoLogo"> </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
          aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <h1 class="Titulo">Vinculo Familiar</h1>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav barra">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Inicio</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Pagina2.php">Los juegos en la familia</a>
            </li>

            <li class="nav-item">
              <a class="nav-link Disabled" href="Pagina4.php">Acerca de nosotros</a>
            </li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                Sesiones
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="Pagina3.php">Mas informacion</a></li>
                <li><a class="dropdown-item" href="Patients/add.php">Registrarse</a></li>
                

              </ul>
            </li>

          </ul>
        </div>
      </div>
    </nav>
  </header>
  <!-- Decorado del encabezado -->
  <div class="linea1"></div>
  <div class="intermidianline2"></div>
  <p class="textobanner">¡LOS VINCULOS SE CREAN EN EL HOGAR!</p>
  <div class="rectangulo"></div>
  <div class="intermidianline1"></div>
  <div class="intermidianline4"></div>
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="false">
    <!-- Carrusel -->
    <div class="carousel-indicators bg-dark" width="600px">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
        aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
        aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
        aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="Imagenes/img0.jpg" class="d-block w-80" alt="La eduacion" width="800px" height="700px">
        <div class="carousel-caption d-none d-md-block">
          <h5>La literatura como juego.</h5>
          <p>La importacia de la literatura para el bien de los infantes.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="Imagenes/imgg1.jpg" class="d-block w-80" alt="Lectura" width="800px" height="700px">
        <div class="carousel-caption d-none d-md-block">
          <h5>La interaccion del juego entre padres e hijos.</h5>
          <p>Fortalecer los lazos presentes en la familia es una forma de bienestar.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="Imagenes/img2.jpg" class="d-block w-80" alt="El-juego" width="800px" height="700px">
        <div class="carousel-caption d-none d-md-block">
          <h5>Vinculos en la familia.</h5>
          <p>Los vinculos unen a todas las familias.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev bg-dark" type="button" data-bs-target="#carouselExampleCaptions"
      data-bs-slide="prev">
      <span class="carousel-control-prev-icon bg-dark" aria-hidden="true"></span>
      <span class="visually-hidden bg-dark">Anterior</span>
    </button>
    <button class="carousel-control-next bg-dark" type="button" data-bs-target="#carouselExampleCaptions"
      data-bs-slide="next">
      <span class="carousel-control-next-icon bg-dark" aria-hidden="true"></span>
      <span class="visually-hidden bg-dark">Siguiente</span>
    </button>
  </div>
  <!-- Primer parro e imagen -->

  <div class="intermidianline5"></div>
  <div class="intermidianline"></div>
  <div class="contenedor">
    <div clase="Articulo0">
      <article>
        <p class="texto">
        El juego como creación de vínculos afectivos en el entorno familiar.
        <br>
Los miembros de la familia es el primer vínculo afectivo en el proceso de reconocimiento mutuo de cada individuo.  El juego tiene un papel importante en la comunicación bebe-adulto, bebe-niño-niña construyendo lazos de confianza y seguridad, así como intercambiar sentimientos de manera reciproca, los niños aprender a leer las emociones del adulto como los gestos, tono de voz y miradas.
El juego y la literatura les brinda un mundo de exploraciones a los niños y niñas en sus diferentes etapas de crecimiento, ya que les permite interactuar con los adultos y cuidadores, influenciados por la imitación o representación de vivencias cotidianas, de manera verbal, no verbal, de contacto corporal los cuales estan enmarcados en las costumbres, creencias y tradiciones culturales que se viven dentro de cada familia.
        </p>

      </article>
    </div>
    <div class="img1">
      <img src="Imagenes/img1.jpg" alt="JuegoImagen1" class="rounded float-start">

    </div>
    <div clase="Articulo">
      <article>
        <p class="texto0">
          La literatura en la educación inicial juega un papel relevante, puesto que definirá su comunicación escrita,
          aparte de ser la herramienta esencial para cimentar la personalidad de las niñas y niños, Se quiere llevar a
          la
          práctica que las familias se comprometan a incluir en su entorno como la literatura , expresiones artísticas y
          la exploración del medio, estableciendo vínculos afectivos con pares y adultos significativos, diferentes a
          los
          de su familia, a relacionarse con el ambiente natural, social y cultural,que es fundamental en el estudio
          frente
          a los pilares de educación inicial, como estrategia didáctica para la enseñanza de la literatura en la primera
          infancia.
        </p>
      </article>

    </div>

   </div>    
  <!--  --> 

  <div class="contenedor">
    <div clase="Articulo0">
      <article>
        <p class="texto">
          Los niños deben ser reconocidos como sujetos sociales y como ciudadanos con derechos en contextos democráticos .


        </p>

      </article>
    </div>
    <div class="img1">
      <img src="Imagenes/im1.png" alt="JuegoImagen1" class="rounded float-start">

    </div>
    <div clase="Articulo">
      <article>
        <p class="texto0">
          Se construyen nuevas significaciones y comprensiones como el juego fortalece los vínculos afectivos en la familia. Se puede identificar las características necesarias para estrechar los vínculos entre el adulto y el niño-niña, con el juego se posibilita el reconocimiento de las personas y el entorno que nos rodea, se construye identidad, autonomia, espacios de socialización y construcción, se puede observar como se encuentra los miembros de la familia en su relación padres, abuelos, el entorno y la sociedad.
        </p>
      </article>

    </div>

   </div>    
  

  <!--  -->
        <!-- Pie de pagina -->
        <footer class="pie-pagina">
          <div class="grupo-1">
            <div class="box">
              <figure>
                <a href="#">
                  <img src="Imagenes/Juego.png" alt="Vinculos FAMILIARES">
                </a>
              </figure>
            </div>
            <div class="box">
              <h2>EL JUEGO COMO VINCULO</h2>
              <p>Cada familia debe esforzarse en crear buenos y vinculos especiales
                Por: Maria Brigida Ruiz
              </p>

            </div>
            <div class="box">
              <h2>SIGUENOS</h2>
              <div class="red-social">
                <a href="#" class="fa fa-facebook"></a>
                <a href="#" class="fa fa-instagram"></a>
                <a href="#" class="fa fa-twitter"></a>
                <a href="#" class="fa fa-youtube"></a>
              </div>
          </div>
         

        </footer>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
          integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
          crossorigin="anonymous"></script>

</body>

</html>